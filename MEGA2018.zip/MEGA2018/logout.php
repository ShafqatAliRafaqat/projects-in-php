<?php
session_start();
unset($_SESSION['mega2018']);
header("location:index.php")
?>